/**
   io.h - v0.1 - 01/02/2019
   @uthor  : PUC-Minas - ICEI - CRC
   @version: 0.1
   All rights reserved.

   Windows installation:
    copy file io.h    to include folder
    copy file libio.a to lib     folder

   Include:
   #include <io.h>

   Compile:
   gcc -o test_io.exe test_io.c -lio

   Run:
   test_io
 */
 // dependencias
#include <stdio.h>                  // para as entradas e saidas
#include <stddef.h>                 // para outras definicoes padroes
#include <stdlib.h>                 // para a biblioteca padrao
#include <stdarg.h>                 // para argumentos
#include <stdbool.h>                // para valores logicos
#include <string.h>                 // para cadeias de caracteres
#include <math.h>                   // para funcoes matematicas
#include <ctype.h>                  // para definicoes associadas aos tipos

/**
   Global definitions.
 */
#define IO_printf   printf          // definir sinonimo
#define IO_scanf    scanf           // definir sinonimo
#define IO_fprintf  fprintf         // definir sinonimo
#define IO_fscanf   fscanf          // definir sinonimo

#define FALSE       false
#define TRUE        true

#define EOS         '\0'            // definir fim de cadeia de caracteres
#define EOL         '\n'            // definir mudanca de linha
#define ENDL        "\n"            // definir mudanca de linha
#define STR_EMPTY   ""              // definir cadeia de caracteres vazia
#define STR_SIZE    80              // definir tamanho padrao para caracteres

/**
   Global data types.
 */
typedef char*       chars  ;        // definir cadeia  de caracteres
typedef int*        ints   ;        // definir arranjo de inteiros
typedef double*     doubles;        // definir arranjo de reais (precisao dupla  )
typedef float*      floats ;        // definir arranjo de reais (precisao simples)
typedef bool*       bools  ;        // definir arranjo de logicos


/**
   Global external variable.
 */
extern int IO_error;                // sem erros


//  ---------------------------------- OS dependent

/**
    Metodo para limpar a entrada de dados (terminal).
 */
void IO_flush ( );

/**
    Metodo para limpar a tela (terminal).
 */
void IO_clrscr ( );

//  ---------------------------------- identification

/**
    Funcao para informar a versao atual da IO.
    @return versao da IO
 */
chars IO_version ( );


/**
    Metodo para identificar o programa e a autoria.
    @param text - mensagem a ser exibida
 */
void IO_id ( chars text );

//  ---------------------------------- data type allocation

/**
    Funcao para reservar espaco para guardar cadeia de caracteres.
    @return area reservada, se houver; NULL, caso contrario
    @param size - quantidade de dados
 */
chars IO_new_chars ( int size );

/**
    Funcao para reservar espaco para guardar inteiros.
    @return area reservada, se houver; NULL, caso contrario
    @param size - quantidade de dados
 */
ints IO_new_ints ( int size );

/**
    Funcao para reservar espaco para guardar reais.
    @return area reservada, se houver; NULL, caso contrario
    @param size - quantidade de dados
 */
doubles IO_new_doubles ( int size );

/**
    Funcao para reservar espaco para guardar reais (precisao simples).
    @return area reservada, se houver; NULL, caso contrario
    @param size - quantidade de dados
 */
floats IO_new_floats ( int size );

/**
    Funcao para reservar espaco para guardar logicos.
    @return area reservada, se houver; NULL, caso contrario
    @param size - quantidade de dados
 */
bools IO_new_bools ( int size );

//  ---------------------------------- characters utilities

/**
    Funcao para concatenar cadeias de caracteres.
    @return cadeia com o resultado
    @param text1 - primeira cadeia
    @param text2 - segunda  cadeia
 */
chars IO_concat ( chars text1, chars text2 );

/**
    Funcao para converter valor logico para caracteres.
    @return cadeia com o resultado
    @param x     - valor logico
 */
chars IO_toString_b ( bool x );

/**
    Funcao para converter caractere para caracteres.
    @return cadeia com o resultado
    @param x     - caractere
 */
chars IO_toString_c ( char x );

/**
    Funcao para converter inteiro para caracteres.
    @return cadeia com o resultado
    @param x     - valor inteiro
 */
chars IO_toString_d ( int x );

/**
    Funcaoo para converter real para caracteres.
    @return cadeia com o resultado
    @param x     - valor real
 */
chars IO_toString_f ( double x );

//  ---------------------------------- input/output

/**
    Metodo para mostrar uma linha com certo texto.
    @param text1 - primeira cadeia
 */
void IO_print ( chars text1 );

/**
    Metodo para mostrar uma linha com certo texto
    e mudar de linha.
    @param text1 - primeira cadeia
 */
void IO_println ( chars text1 );

/**
    Metodo para gravar uma linha em arquivo texto.
    @param filePtr - referencia para arquivo aberto
    @param text1 - cadeia de caracteres a ser gravada
 */
void IO_fprint ( FILE* filePtr, chars text1 );

/**
    Metodo para gravar uma linha em arquivo texto
    e mudar de linha.
    @param filePtr - referencia para arquivo aberto
    @param text1 - cadeia de caracteres a ser gravada
 */
void IO_fprintln ( FILE* filePtr, chars text1 );

/**
    Funcao para ler valor inteiro.
    @return valor lido
    @param text1 - mensagem a ser exibida antes da leitura
 */
bool IO_readbool ( chars text1 );

/**
    Funcao para caractere.
    @return valor lido
    @param text1 - mensagem a ser exibida antes da leitura
 */
char IO_readchar ( chars text1 );

/**
    Funcao para ler valor real.
    @return valor lido
    @param text1 - mensagem a ser exibida antes da leitura
 */
double IO_readdouble ( chars text1 );

/**
    Funcao para ler valor real (precisao simples).
    @return valor lido
    @param text1 - mensagem a ser exibida antes da leitura
 */
float IO_readfloat ( chars text1 );

/**
    Funcao para ler valor inteiro.
    @return valor lido
    @param text1 - mensagem a ser exibida antes da leitura
 */
int IO_readint ( chars text1 );

/**
    Funcao para ler cadeia de caracteres.
    @return cadeia de caracteres
    @param text1 - mensagem a ser exibida antes da leitura
 */
chars IO_readstring ( chars text1 );

/**
    Funcao para ler uma linha inteira.
    @return linha lida
    @param text1 - mensagem a ser exibida antes da leitura
 */
chars IO_readln ( chars text1 );

/**
    Metodo para indicar uma pausa (esperar por ENTER).
    @param text - mensagem a ser exibida antes da espera
 */
void IO_pause ( chars text );

/**
    Funcao para ler uma palavra de arquivo.
    @return palavra lida
    @param arquivo - referencia para arquivo aberto
 */
chars IO_fread ( FILE* filePtr );

/**
    Funcao para ler uma linha inteira.
    @return linha lida
    @param filePtr - referencia para arquivo aberto
 */
chars IO_freadln ( FILE* filePtr );

//  ---------------------------------- debug utilities

/**
    Metodo para auxiliar na depuracao.
    @param test   - valor ou condicao a ser avaliada
    @param format - formato para os valores a serem exibidos
    @param ...    - valores a serem exibidos
 */
void IO_debug ( int test, const chars format, ... );
